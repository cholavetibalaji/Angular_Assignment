﻿using AngloAmerican.Account.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace AngloAmerican.Account.Api.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class AccountController : ControllerBase
    {
        private readonly IAddressService addressService;

        public AccountController(IAddressService addressService)
        {
            this.addressService = addressService;
        }
        /* TODO
            - Create a REST API to get all the accounts
                For every account you need to use AddressService to load an address (City and PostCode)
                You can use AccountResponse class
                
            - Create a REST API to save an account 
                Call BalanceChecker to verify if you can save
                You can use AccountRequest class as a payload
         */
        [HttpGet]
        public string Hello()
        {
            return "Welcome!!";
        }
        [HttpGet]
        public List<AccountResponse> GetAllAccounts(int typeId)
        {
            List<AccountModel> accountModels = addressService.GetAllAccounts();

            List<AccountResponse> accountResponses = new List<AccountResponse>();
            AccountResponse accountResponse;
            foreach (AccountModel accountModel in accountModels)
            {
                accountResponse = new AccountResponse();

                accountResponse.FirstName = accountModel.FirstName;
                accountResponse.LastName = accountModel.LastName;
                accountResponse.Balance = accountModel.Balance;
                accountResponse.TypeId = getAccountTypeId(accountModel.Balance);
                accountResponse.Address = addressService.GetAddress();
                accountResponses.Add(accountResponse);
            }
            if (typeId != 0)
                return accountResponses.Where(a => a.TypeId == typeId).ToList();
            return accountResponses;
        }
        [HttpPost]
        public void AddAccount(AccountRequest accountRequest)
        {
            AccountModel accountModel = new AccountModel();
            //mapping code.
            accountModel.FirstName = accountRequest.FirstName;
            accountModel.LastName = accountRequest.LastName;
            accountModel.Balance = accountRequest.Balance;
            BalanceChecker balanceChecker = new BalanceChecker();
            Notification notification = new Notification();
            ExternalApi externalApi = new ExternalApi();

            if (balanceChecker.Process(accountModel.Balance, notification, externalApi, accountModel.LastName))
                addressService.AddAccount(accountModel);
        }
        private int getAccountTypeId(int balance)
        {
            int TypeId = 0;
            if (balance <= 5000)
                TypeId = 1;
            else if (balance > 5000 && balance <= 10000)
                TypeId = 2;
            if (balance > 10000)
                TypeId = 3;

            return TypeId;

        }
    }
}