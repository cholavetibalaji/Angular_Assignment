﻿namespace AngloAmerican.Account.Api
{
    public class AccountType
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}