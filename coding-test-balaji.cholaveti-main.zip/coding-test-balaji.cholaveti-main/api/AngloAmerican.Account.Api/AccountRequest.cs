﻿namespace AngloAmerican.Account.Api
{
    public class AccountRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Balance { get; set; }
    }
}