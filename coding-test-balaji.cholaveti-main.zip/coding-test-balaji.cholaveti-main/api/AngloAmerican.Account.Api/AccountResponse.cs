﻿namespace AngloAmerican.Account.Api
{
    public class AccountResponse
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int TypeId { get; set; }
        public int Balance { get; set; }
        public string Address { get; set; }
    }
}