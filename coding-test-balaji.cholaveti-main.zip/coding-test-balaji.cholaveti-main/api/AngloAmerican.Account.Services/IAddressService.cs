﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace AngloAmerican.Account.Services
{
    public interface IAddressService
    {
        string GetAddress();
        List<AccountModel> GetAllAccounts();
        Task AddAccount(AccountModel accountModel);
    }
}