﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace AngloAmerican.Account.Services
{
    public interface IAccountRepository
    {
        Task Add(AccountModel accountModel);
        List<AccountModel> GetAllAccounts();
    }
}