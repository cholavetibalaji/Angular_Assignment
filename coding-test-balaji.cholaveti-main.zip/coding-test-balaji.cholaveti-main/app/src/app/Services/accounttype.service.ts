import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ServiceUrl } from '../contracts/Const';
import { BehaviorSubject, Observable } from 'rxjs';
import { AccountTypeModel } from '../account-type/account-type.model';
@Injectable({
  providedIn: 'root'
})

export class AccountType {
    constructor(private httpClient: HttpClient) { }
    private bSubject$: BehaviorSubject<any> = new BehaviorSubject<any>(0);
    public accountTypeIdSubject$: Observable<any> = this.bSubject$.asObservable();

  public getAccountType(): any {
    return this.httpClient.get(ServiceUrl.RootUrl + ServiceUrl.AccountTypeApi);
  }

public setAccountType(value): any
{
 this.bSubject$.next(value);
}

}

