import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { ServiceUrl } from '../contracts/Const';
import { Account } from '../contracts/account';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private httpClient: HttpClient) { }
  public getAllAccounts(typeId): any {
    const apiEndPoint = ServiceUrl.RootUrl + ServiceUrl.AccountApi + `GetAllAccounts?typeId=${typeId}`;
    return this.httpClient.get(apiEndPoint);
  }
  public addAccount(accountModel: Account): any {
    const apiEndPoint = ServiceUrl.RootUrl + ServiceUrl.AccountApi + 'AddAccount';
    return this.httpClient.post(apiEndPoint, accountModel);
  }
}
