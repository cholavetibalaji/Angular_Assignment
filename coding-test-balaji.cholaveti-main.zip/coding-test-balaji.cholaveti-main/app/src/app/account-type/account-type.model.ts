export interface AccountTypeModel{
  id: number;
  name: string;
}
