import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AccountType } from '../Services/accounttype.service';
import { AccountTypeModel } from './account-type.model';

@Component({
  selector: 'app-account-type',
  templateUrl: './account-type.component.html'
})
export class AccountTypeComponent implements OnInit {

  /* TODO:
  - Load Accounts Types from the REST Api
  - Observable should be used to notify the account.component about changes in the selected Type
   */
  accountTyes = [];
  constructor(public accountType: AccountType ) {
  }
   ngOnInit(): void {
    this.accountType.getAccountType().subscribe((data: any[]) => {
    console.log(data);
    this.accountTyes = data;
    // console.log(this.accountTyes);
  });
  }
  onChange(value: string): void{
    this.accountType.setAccountType(value);
  }

}
