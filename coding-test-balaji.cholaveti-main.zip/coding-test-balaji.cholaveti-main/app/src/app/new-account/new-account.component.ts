import { Component, OnInit } from '@angular/core';
import { AccountModel } from '../account/account.model';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ServiceUrl } from '../contracts/Const';
import { AccountType } from '../Services/accounttype.service';
import { Account } from '../contracts/account';
import { AccountService } from '../Services/account.service';
@Component({
  selector: 'app-new-account',
  templateUrl: './new-account.component.html'
})
export class NewAccountComponent implements OnInit {

  /* TODO:
 - Save account using the REST Api
  */
//  accountModel =  new AccountModel("","",0,0,"");
public accountModel = new Account("","",0);
  constructor(private accountService: AccountService) {
  }

  ngOnInit(): void {
  }
  onSubmit()
  {
    console.log(this.accountModel);
    
    this.accountService.addAccount(this.accountModel)
                  .subscribe(
                    // data=>console.log('success!!'),
                    // error=>console.log('error!!')
                    );
  
  }
  // saveAccount(){
  //   // console.log(this.accountModel);
  // }

}
