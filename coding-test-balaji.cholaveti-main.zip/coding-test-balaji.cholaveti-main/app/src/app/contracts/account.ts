export class Account {
  constructor(public firstName: string,
              public lastName: string,
              public balance: number
  ) { }
}
