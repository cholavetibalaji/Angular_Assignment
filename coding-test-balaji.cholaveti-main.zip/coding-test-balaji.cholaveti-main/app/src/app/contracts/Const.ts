export class ServiceUrl {
    public static get RootUrl() {
        return "https://localhost:5001";
    }
    public static get AccountApi() {
        return "/Account/";
    }
    public static get AccountTypeApi() {
        return "/accounttype/";
    }
    public static get AddAccountApi() {
        return "/AddAccount/";
    }
}