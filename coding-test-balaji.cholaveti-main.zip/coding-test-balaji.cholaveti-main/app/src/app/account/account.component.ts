import { Component, OnInit } from '@angular/core';
import { AccountType } from '../Services/accounttype.service';

import { AccountService } from '../Services/account.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html'
})
export class AccountComponent implements OnInit {

  /* TODO:
  - Load Accounts from the REST Api
  - Display Accounts in the HTML Table
  - Filter Accounts based on the Account Type
   */
  accountTypeId: any;
  accountTypeBsubject: any;

  constructor(private accountService: AccountService,private router:Router,private accountType: AccountType ) {
    this.accountTypeBsubject = this.accountType.accountTypeIdSubject$.subscribe(data => {
      this.accountTypeId = data;
      
      let result = this.accountService.getAllAccounts(this.accountTypeId).subscribe((data: any[])=>{      
        this.accounts = data;
        // console.log(this.accounts);
     
     });
    });
    
  }
 
accounts = []
  ngOnInit(): void {    
   
  }

  openNewAccount(): void {
    
     this.router.navigate(['/new-account']);
  }

  
}
